Group Members:
1. Piyush Tiwary (1701EE31) - Implemented Decision Tree Algorithm from Scratch & Ploted Results
2. Chandan Kumar (1701CS16) - Used the DT implementation to write the code for Question 1
3. Akanksha Gupta (2021EE35) - Used the DT implementation to write the code for Question 2

------------------------------------------------------

The Directory is Organized as follows:

1. Code: Contains all the codes used to obtain the results

2. Plots & Result: Contains all Plots asked in the Assignment & Screensots of the Results of Question 1 & 2

