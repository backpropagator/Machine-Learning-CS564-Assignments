The Directory is Organized as follows:

1. Codes: Contains all the codes used to obtain the results

2. Data: Contains all the 3 Dataset mentioned in Assignment

3. Results: Contains PDF of IPython Notebook which contains results in the cell outputs.

4. ML Assignmet 2 Report.pdf: Report of the observations as mentioned in the Assignment.