The Directory is Organized as follows:

1. Code: Contains all the codes used to obtain the results

2. Result: Contains the Observations and Results corresponding to each question


Note: This Submission is made Individually by Me (1701EE31)